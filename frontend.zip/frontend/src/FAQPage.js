// src/FAQPage.js
import React from "react";

const FAQPage = () => {
  return (
    <div className="form-container">
      <h2>Frequently Asked Questions</h2>
      <p><strong>Q:</strong> How can I donate food?</p>
      <p><strong>A:</strong> Log in and go to the Donate page to submit your food donation.</p>

      <p><strong>Q:</strong> Is it free to order food?</p>
      <p><strong>A:</strong> Yes, it’s absolutely free.</p>

      <p><strong>Q:</strong> How can I contact support?</p>
      <p><strong>A:</strong> Visit the Contact page for our details.</p>
    </div>
  );
};

export default FAQPage;
